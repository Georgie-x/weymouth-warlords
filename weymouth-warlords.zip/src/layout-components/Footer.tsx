function Footer() {
	return (
		<footer>
			<div className='footer-container'>
				<p>&#169; Georgina Rimmer 2024</p>
			</div>
		</footer>
	)
}

export default Footer
