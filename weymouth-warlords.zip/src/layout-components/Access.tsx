function Access() {
    return (
      <a href="#welcome" className="skip-to-content">
        Skip to Content
      </a>
    );
  }
  
  export default Access