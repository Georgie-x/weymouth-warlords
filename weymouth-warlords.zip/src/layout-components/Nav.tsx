function Nav() {
	return (
		<>
			<p>nav</p>
		</>
	)
}
export default Nav
