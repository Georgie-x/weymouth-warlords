function Forum() {
	return (
		<>
			<p>Forum</p>
		</>
	)
}

export default Forum