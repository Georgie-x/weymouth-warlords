function Events() {
	return (
		<>
			<p>Events</p>
		</>
	)
}

export default Events
