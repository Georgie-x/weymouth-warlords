function User() {
	return (
		<>
			<p>User</p>
		</>
	)
}

export default User