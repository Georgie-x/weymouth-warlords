function ErrorPage() {
	return (
		<>
			<p>ErrorPage</p>
		</>
	)
}

export default ErrorPage
