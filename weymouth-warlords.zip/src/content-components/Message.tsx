function Message() {
	return (
		<>
			<p>Message</p>
		</>
	)
}

export default Message