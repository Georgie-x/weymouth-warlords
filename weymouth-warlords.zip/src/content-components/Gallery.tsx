function Gallery() {
	return (
		<>
			<p>Gallery</p>
		</>
	)
}

export default Gallery