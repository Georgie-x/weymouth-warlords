import Events from "./Events"
import Forum from "./Forum"
import Home from "./Home"
import Gallery from "./Gallery"
import Links from "./Links"
import Message from "./Message"
import ErrorPage from "./ErrorPage"
import Menu from "./Menu"

export {Events, Forum, Home, Gallery, Links, Message, ErrorPage, Menu}