function Links() {
	return (
		<>
			<p>Links</p>
		</>
	)
}

export default Links